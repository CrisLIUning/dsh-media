/** Safe host diagnostics: deliberately separate from authorization URLs and grants. */
export interface SignInAttempt {
    readonly id: string;
    readonly phase: 'preparing' | 'waiting-browser' | 'exchanging' | 'committing' | 'succeeded' | 'failed' | 'cancelled' | 'expired';
    readonly expiresAt: number;
    readonly gatewayOrigin: string;
    readonly stage?: 'listen' | 'device' | 'redeem' | 'persist';
    readonly errorCode?: 'network' | 'timeout' | 'gateway-refused' | 'gateway-unavailable' | 'protocol' | 'storage' | 'callback';
    readonly httpStatus?: number;
    readonly networkCode?: string;
}
export declare const REDEEM_PATH = "/api/v1/vibedev/link/redeem";
export type SignInFailure = Pick<SignInAttempt, 'errorCode' | 'httpStatus' | 'networkCode'>;
/** Read only fixed transport codes, never error text, stack, body or arbitrary fields. */
export declare function transportFailure(error: unknown): SignInFailure;
/** A fixed bilingual explanation suitable for exposed rejection messages. */
export declare function failureMessage(attempt: Pick<SignInAttempt, 'errorCode' | 'stage' | 'httpStatus'>): string;
/** Only our fixed explanation and escaped safe enum/status fields reach the browser. */
export declare function failurePage(attempt: SignInAttempt): string;
/** Explicit log allowlist; adding fields to the public attempt never expands log output. */
export declare function attemptLog(event: 'request' | 'phase' | 'response' | 'terminal', attempt: SignInAttempt): string;
