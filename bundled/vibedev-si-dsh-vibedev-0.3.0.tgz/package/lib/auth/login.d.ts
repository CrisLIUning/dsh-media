/**
 * The plugin's own VibeDev sign-in, for hosts whose account service does not
 * hold a VibeDev session (official DeepSeek Harness). Authorization code with
 * PKCE (S256) through the system browser and a loopback callback on
 * 127.0.0.1; the gateway issues a plugin session (`client=vibedev-plugin`)
 * whose access token is refreshed with a rotating refresh token.
 *
 * Contract (gateway vibedev204):
 * - browser: `{origin}/vibedev-link?callback=http://127.0.0.1:<port>/<path>&state&response_type=code&code_challenge&code_challenge_method=S256&client=vibedev-plugin`
 * - `POST /api/v1/vibedev/link/redeem {code, code_verifier, token_type:'app', client, device_id, device_model, os_version}`
 * - `POST /api/v1/vibedev/app-token/refresh {refresh_token, device_id}`: a new pair every time; the old refresh token dies
 * - `POST /api/v1/vibedev/app-token/revoke` (bearer or `{refresh_token}`): always 204
 * @module dsh-vibedev/auth/login
 */
import type { SignInAttempt } from './sign-in-state.js';
export type { SignInAttempt } from './sign-in-state.js';
/** A stored plugin session. */
export interface PluginGrant {
    /** Origin that issued this stored app grant; legacy unmarked grants belong to the domestic gateway only. */
    readonly gatewayOrigin?: string;
    readonly accessToken: string;
    readonly refreshToken: string;
    /** Epoch ms. */
    readonly expiresAt: number;
    readonly refreshExpiresAt: number;
    readonly sessionId?: string;
    readonly user?: {
        readonly id?: string;
        readonly email?: string;
        readonly nickname?: string;
    };
}
/** What a read-modify-write of the stored grant does. */
export type GrantChange = {
    readonly kind: 'keep';
} | {
    readonly kind: 'set';
    readonly grant: PluginGrant;
} | {
    readonly kind: 'delete';
};
/** Where the grant and the device id live. */
export interface GrantStorage {
    read(): Promise<PluginGrant | undefined>;
    write(grant: PluginGrant | undefined): Promise<void>;
    /**
     * Read-modify-write of the stored grant, one at a time across processes
     * where the store supports it, so two processes never spend one refresh token.
     * @param change - decides the change from the grant as stored now.
     */
    update(change: (current: PluginGrant | undefined) => Promise<GrantChange>): Promise<void>;
    /** A stable id for this installation, sent on redeem and on every refresh. */
    deviceId(): Promise<string>;
}
/** Construction options; `fetch`, the clock and `openBrowser` are test seams. */
export interface PluginLoginOptions {
    readonly origin: string;
    readonly storage: GrantStorage;
    readonly userAgent: string;
    readonly fetch?: typeof globalThis.fetch;
    readonly now?: () => number;
    /** Open a URL in the system browser; resolves whether that was attempted successfully. */
    readonly openBrowser?: (url: string) => Promise<boolean>;
    /** Sign-in deadline through credential exchange, before the atomic write starts. Defaults to 5 minutes. */
    readonly signInTimeoutMs?: number;
    /** The client name the gateway records for the sign-in (it picks the key the usage is billed to). Defaults to `vibedev-plugin`. */
    readonly client?: string;
    readonly log?: (message: string) => void;
}
/** A sign-in waiting for the browser. */
export interface PendingSignIn {
    readonly url: string;
    readonly expiresAt: number;
    /** Settles when the sign-in completes, fails or times out. */
    readonly done: Promise<PluginGrant>;
}
/**
 * Read a token answer (`redeem` or `refresh`).
 * @param body - the parsed envelope `{code, data}` or a bare data object.
 * @param now - current epoch ms.
 * @param previous - the grant being refreshed, whose identity carries over.
 * @returns the grant, or undefined when the answer lacks tokens.
 */
export declare function parseGrant(body: unknown, now: number, previous?: PluginGrant): PluginGrant | undefined;
/**
 * Open a URL in the system browser without a shell (an `&` in the URL must not split a command line).
 * @param url - the URL.
 * @returns whether the opener started.
 */
export declare function openInBrowser(url: string): Promise<boolean>;
/** The plugin's VibeDev session. */
export declare class PluginLogin {
    private readonly options;
    private grant;
    private reading;
    private revision;
    private readFailureReported;
    private refreshing;
    private pending;
    private attempt;
    private readonly listeners;
    private readonly now;
    private readonly origin;
    /**
     * @param options - gateway origin, storage and test seams.
     */
    constructor(options: PluginLoginOptions);
    private readStored;
    private load;
    /** Re-read after the credential provider becomes ready or its record changes, without starting a browser sign-in. */
    restore(): Promise<void>;
    /** Take a grant as current and tell listeners when it changed. */
    private adopt;
    private notify;
    /** A copied safe snapshot, retained after completion until the next sign-in. */
    signInAttempt(): SignInAttempt | undefined;
    private logAttempt;
    private transition;
    private save;
    /**
     * Hear about sign-in and sign-out.
     * @param listener - called after every change.
     * @returns unsubscribe.
     */
    onChange(listener: () => void): () => void;
    /** The signed-in user, or undefined while signed out. */
    user(): Promise<PluginGrant['user'] | undefined>;
    /** Whether a sign-in is waiting for the browser, and its link. */
    pendingSignIn(): {
        url: string;
        expiresAt: number;
    } | undefined;
    /**
     * The access token for the next request, refreshed when it is about to expire.
     * @returns the token, or undefined while signed out.
     */
    token(): Promise<string | undefined>;
    /**
     * The gateway rejected a token (401): refresh once, unless it already changed.
     * @param token - the rejected token.
     */
    reject(token: string): Promise<void>;
    /**
     * Refresh one grant; concurrent callers share the request. The refresh runs
     * inside the store's read-modify-write: when another process has already
     * rotated the token, its grant is adopted instead of spending the old refresh
     * token, which the gateway would treat as reuse and revoke the session.
     * A rejected refresh signs out.
     */
    private refresh;
    private post;
    /**
     * Start a sign-in: listen on a loopback port, open the authorization page in
     * the system browser, and finish in the background when the browser returns.
     * Starting again while one is waiting returns the waiting one.
     * @param request - `open: false` leaves opening the link to the caller (a page that opens it itself).
     * @returns the authorization link, whether a browser was opened, and the completion.
     */
    startSignIn(request?: {
        open?: boolean;
    }): Promise<PendingSignIn & {
        opened: boolean;
    }>;
    private beginSignIn;
    /** Sign out: revoke the session at the gateway (best effort) and forget it. */
    signOut(): Promise<void>;
    /** Stop a waiting sign-in. */
    dispose(): void;
}
