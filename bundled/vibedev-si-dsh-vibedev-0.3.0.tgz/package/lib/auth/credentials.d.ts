/**
 * Which VibeDev credential a gateway request carries, in order: the host's
 * signed-in VibeDev account (the VibeDev app's account service hands out its
 * token for the gateway origin), the plugin's own sign-in, then a development
 * key named by an environment variable.
 * @module dsh-vibedev/auth/credentials
 */
import type { CredentialProvider } from '@deepseek-ai/dsh-credentials';
import type { DeepSeekAccount } from '@deepseek-ai/dsh-deepseek-account';
import type { GatewayCredential } from '../gateway/http.js';
import type { GrantStorage, PluginLogin } from './login.js';
/** Where a credential came from, for status lines. */
export type CredentialSource = GatewayCredential['kind'];
/** Construction options. */
export interface CredentialChainOptions {
    /** Gateway origin; the host account is asked for a token for this origin. */
    readonly origin: string;
    /** The host's account service, when one is loaded. */
    readonly account: () => DeepSeekAccount | undefined;
    readonly plugin?: PluginLogin;
    /** The development key, when configured. */
    readonly apiKey: () => string | undefined;
}
/** Resolves the credential for each request and routes rejections back to its owner. */
export declare class CredentialChain {
    private readonly options;
    /**
     * @param options - origin and the three sources.
     */
    constructor(options: CredentialChainOptions);
    /** The credential for the next request, or undefined while nobody is signed in. */
    resolve(): Promise<GatewayCredential | undefined>;
    /**
     * The gateway rejected a credential: let its owner refresh it.
     * @param credential - the rejected credential.
     */
    reject(credential: GatewayCredential): Promise<void>;
}
/** Credential identity for one gateway; never consult another gateway's record. */
export declare function gatewayGrantKey(origin: string): import("@deepseek-ai/dsh-credentials").CredentialKey;
/**
 * Grant storage: the host's credential store when one is loaded (a grant
 * record the store keeps verbatim), else a private file in the state
 * directory. The device id is not a secret and lives in the state directory.
 * @param root - the plugin state root; the storage selects an origin-specific directory itself.
 * @param credentials - the host's credential store, when loaded.
 * @param selectedOrigin - the issuing gateway; unmarked historical state is never adopted.
 * @returns the storage.
 */
export declare function grantStorage(root: string, credentials: () => CredentialProvider | undefined, selectedOrigin?: string): GrantStorage;
