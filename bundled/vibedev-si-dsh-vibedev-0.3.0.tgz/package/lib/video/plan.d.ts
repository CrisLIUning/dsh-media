/**
 * Video request planning: choose the generation mode, check every input and
 * option against what the chosen model declares, and build the request body.
 * Everything here runs before anything is uploaded or charged, so a request the
 * model cannot serve fails with a message that lists what it can.
 * @module dsh-vibedev/video/plan
 */
import type { MediaModel, VideoInput, VideoMode, VideoModeConstraint } from '../gateway/catalog.js';
/** What the caller asks for. Sources are workspace paths or URLs. */
export interface VideoRequestOptions {
    readonly prompt: string;
    readonly mode?: VideoMode;
    readonly duration?: number;
    readonly aspectRatio?: string;
    readonly resolution?: string;
    readonly generateAudio?: boolean;
    readonly firstFrame?: string;
    readonly lastFrame?: string;
    readonly referenceImages?: readonly string[];
    readonly referenceVideos?: readonly string[];
    readonly referenceAudios?: readonly string[];
}
/** A checked request, ready for its inputs to be uploaded. */
export interface VideoPlan {
    readonly mode: VideoMode;
    readonly constraint: VideoModeConstraint;
    readonly duration?: number;
    readonly aspectRatio?: string;
    readonly resolution?: string;
    readonly generateAudio?: boolean;
    /** Sources per input, in the caller's order. */
    readonly inputs: Partial<Record<VideoInput, readonly string[]>>;
}
/** The media kind each input carries. */
export declare const INPUT_KIND: Readonly<Record<VideoInput, 'image' | 'video' | 'audio'>>;
/** The `video_generate` parameter each input arrives in; messages name inputs by it. */
export declare const INPUT_PARAM: Readonly<Record<VideoInput, string>>;
/** MIME types the gateway accepts for hosted references when the catalog names none. */
export declare const DEFAULT_REFERENCE_MIMES: Readonly<Record<'image' | 'video' | 'audio', readonly string[]>>;
/** The gateway media library's default per-file ceiling. */
export declare const MEDIA_LIBRARY_MAX_BYTES: number;
/**
 * A one-paragraph account of what a video model accepts, for errors and model listings.
 * @param model - the video model.
 * @returns the description.
 */
export declare function describeVideoModel(model: MediaModel): string;
/**
 * Check a request against the model and fix its mode and options.
 * @param model - the chosen video model.
 * @param options - prompt, mode, options and input sources.
 * @returns the plan.
 * @throws {@link MediaError} naming what the model supports.
 */
export declare function planVideo(model: MediaModel, options: VideoRequestOptions): VideoPlan;
/** One reference's facts, as loaded or uploaded. */
export interface ReferenceMedia {
    readonly source: string;
    readonly mime: string;
    readonly bytes: number;
    /** Measured duration of an uploaded audio or video, in milliseconds. */
    readonly durationMs?: number;
}
/**
 * Check one reference's format and size before it is uploaded.
 * @param model - the video model.
 * @param input - which input it fills.
 * @param media - its type and size.
 * @throws {@link MediaError} when the model or the gateway would refuse it.
 */
export declare function checkReferenceFile(model: MediaModel, input: VideoInput, media: ReferenceMedia): void;
/**
 * The largest file one input may be: the model's per-kind limit, its asset
 * limit and the media library ceiling, whichever is smallest.
 * @param model - the video model.
 * @param input - which input.
 * @returns the limit in bytes.
 */
export declare function referenceByteLimit(model: MediaModel, input: VideoInput): number;
/**
 * Check the measured lengths of the reference media once the gateway has
 * measured them. A reference's OWN length is what is checked — never the
 * requested output duration — and only against the limits that model declares.
 * @param model - the video model.
 * @param videos - the uploaded reference videos, in order.
 * @param audios - the uploaded reference audios, in order.
 * @throws {@link MediaError} when a clip or the total is outside the model's limits.
 */
export declare function checkReferenceDurations(model: MediaModel, videos: readonly ReferenceMedia[], audios?: readonly ReferenceMedia[]): void;
/**
 * The `/v1/videos` body for a plan whose inputs are uploaded. The gateway reads
 * one vocabulary and translates it per provider.
 * @param model - the model id.
 * @param prompt - the prompt.
 * @param plan - the checked plan.
 * @param urls - the gateway reference URL of every input, in order.
 * @returns the request body.
 */
export declare function videoRequestBody(model: string, prompt: string, plan: VideoPlan, urls: Partial<Record<VideoInput, readonly string[]>>): Record<string, unknown>;
