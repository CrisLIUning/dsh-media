/**
 * The VibeDev account as the plugin's pages see it, and the Host routes they
 * call (`/api/dsh-vibedev/account…`, on the client connection like every
 * plugin route):
 *
 * - `GET  /api/dsh-vibedev/account` — where the credential comes from (the
 *   app's account, the plugin's own sign-in, a development key, or none), who
 *   is signed in, the balance, a sign-in waiting for the browser, and how many
 *   VibeDev models the pickers list; `?fresh=1` reads the balance again;
 * - `POST /api/dsh-vibedev/account/sign-in` — `{ open?: boolean }`: start the
 *   plugin's own sign-in; answers the authorization link (`open: false` leaves
 *   opening it to the page);
 * - `POST /api/dsh-vibedev/account/cancel` — stop a waiting sign-in;
 * - `POST /api/dsh-vibedev/account/sign-out` — end the plugin's own sign-in
 *   (an app account is signed out in the app, so that answers 409).
 *
 * The DeepSeek account is never touched: it stays the Harness's own.
 * @module dsh-vibedev/account
 */
import type { ConnectionFetchRoute } from '@deepseek-ai/dsh-client-connection';
import type { CredentialChain } from '../auth/credentials.js';
import type { PluginLogin, SignInAttempt } from '../auth/login.js';
/** Path prefix of the plugin's Host routes. */
export declare const ACCOUNT_ROUTE_PREFIX = "/api/dsh-vibedev/account";
/** Where the active credential comes from. */
export type AccountSource = 'host' | 'plugin' | 'key' | 'none';
/** What the account pages render. */
export interface AccountView {
    readonly source: AccountSource;
    /** The signed-in person, when known. */
    readonly user?: {
        readonly id?: string;
        readonly email?: string;
        readonly nickname?: string;
    };
    /** The balance, when it could be read. */
    readonly balance?: {
        readonly amount: string;
        readonly currency: string;
    };
    /** A sign-in waiting for the browser. */
    readonly pending?: {
        readonly url: string;
        readonly expiresAt: number;
    };
    /** Safe sign-in progress or the most recent terminal diagnostic. */
    readonly attempt?: SignInAttempt;
    /** VibeDev chat models the pickers list now, and why there are none. */
    readonly models: {
        readonly count: number;
        readonly hidden?: 'signed-out' | 'host-account';
    };
    /** Pages on the gateway's site. */
    readonly links: {
        readonly topUp: string;
        readonly register: string;
        readonly usage: string;
    };
    /** The VibeDev account is the app's main account (the VibeDev app): its row leads the sidebar foot and Settings. */
    readonly primary: boolean;
}
/** What the account routes need from the plugin. */
export interface AccountServiceOptions {
    readonly origin: string;
    readonly userAgent: string;
    readonly chain: CredentialChain;
    readonly login: PluginLogin;
    /** The VibeDev route's model count and why it is empty. */
    readonly models: () => {
        count: number;
        hidden?: 'signed-out' | 'host-account';
    };
    /** Present the VibeDev account as the app's main account. */
    readonly primary?: boolean;
    readonly fetch?: typeof globalThis.fetch;
    readonly now?: () => number;
}
/** The account state behind the pages. */
export declare class AccountService {
    private readonly options;
    private balanceCache;
    private readonly now;
    /**
     * @param options - origin, credential chain, the plugin's sign-in and the route's model state.
     */
    constructor(options: AccountServiceOptions);
    /** Links to the gateway's pages. */
    links(): AccountView['links'];
    /**
     * The account as it stands.
     * @param fresh - read the balance again instead of reusing a recent read.
     * @returns the view.
     */
    view(fresh?: boolean): Promise<AccountView>;
    /** `GET /v1/account/auth/me` for one token, reused for a minute. */
    private me;
    /**
     * Start the plugin's own sign-in.
     * @param open - open the system browser (false: the page opens the link itself).
     * @returns the authorization link and whether a browser was opened.
     */
    signIn(open: boolean): Promise<{
        url: string;
        expiresAt: number;
        opened: boolean;
    }>;
    /** Stop a waiting sign-in. */
    cancel(): void;
    /**
     * End the plugin's own sign-in.
     * @returns false when the credential is the app's account, which is signed out in the app.
     */
    signOut(): Promise<boolean>;
}
/**
 * The account routes.
 * @param account - the account service.
 * @returns routes for the client connection.
 */
export declare function accountRoutes(account: AccountService): ConnectionFetchRoute[];
