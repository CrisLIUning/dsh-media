/**
 * The VibeDev gateway behind the Harness LLM seam.
 *
 * Shaped after `@deepseek-ai/dsh-llm-pi-ai`'s adapter (src/adapter.ts,
 * dsh-v0.2.0-rc.2): one immutable snapshot per catalog, captured before an
 * operation's first await, so a catalog refresh mid-reply only affects the next
 * step. What differs is what a gateway needs:
 *
 * - one route serves every protocol, each model naming its own (see models.ts);
 * - the credential is the account's access token (or a development key), sent
 *   as `Authorization: Bearer` on every protocol;
 * - Anthropic requests carry `metadata.user_id = {device_id, session_id}` and
 *   OpenAI requests `session_id` and `prompt_cache_key`, which is how the gateway
 *   keeps one session on one upstream account so its prompt cache keeps hitting;
 * - "off" is spelled out where the catalog offers `none`, and Responses drops
 *   `temperature` while reasoning;
 * - a 401 hands the credential back to its owner and, when the owner renewed it,
 *   sends the request once more; failures carry this plugin's own codes
 *   (`VIBEDEV_SIGN_IN_REQUIRED`, `VIBEDEV_INSUFFICIENT_BALANCE`) because the
 *   Harness's account codes raise the DeepSeek account's prompts.
 *
 * Ported from the VibeDev app's `@vibedev/dsh-llm-gateway` (vibedev-app
 * f08333ee7f), where the same models sit on the app's own account channel.
 *
 * @module dsh-vibedev/llm/adapter
 */
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, ImageAttachmentAccess, LlmModelInfo, LlmProviderInfo, LlmResolvedModelInfo, PreparedAdapterCall, ResolvedRetryPolicy, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { AttachmentStore, ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { GatewayModel } from './catalog.js';
/** The credential for one request. */
export interface GatewayCredential {
    readonly token: string;
    /**
     * `account`: the host app's VibeDev account (the VibeDev app); `plugin`: this
     * plugin's own sign-in; `key`: a development key. Account and plugin tokens
     * go back to their owner on a 401; a development key does not.
     */
    readonly kind: 'account' | 'plugin' | 'key';
}
/**
 * Failure code for "no VibeDev sign-in": deliberately not the Harness's
 * `ACCOUNT_SIGN_IN_REQUIRED`, which belongs to the DeepSeek account and would
 * raise its sign-in prompt; the chat shows this failure's own message.
 */
export declare const SIGN_IN_REQUIRED_CODE = "VIBEDEV_SIGN_IN_REQUIRED";
/** Failure code for a used-up balance; not the Harness's `ACCOUNT_QUOTA`, which opens the DeepSeek top-up. */
export declare const INSUFFICIENT_BALANCE_CODE = "VIBEDEV_INSUFFICIENT_BALANCE";
/** What a person reads when a VibeDev model is used before signing in. */
export declare const SIGN_IN_MESSAGE: string;
/** What a person reads when the gateway ended the sign-in and a refresh could not renew it. */
export declare const SESSION_ENDED_MESSAGE: string;
/**
 * What a person reads on a used-up balance.
 * @param origin - the gateway origin, whose `/purchase` page tops up.
 * @returns the message.
 */
export declare function balanceMessage(origin: string): string;
/** Constructor options for {@link GatewayAdapter}. */
export interface GatewayAdapterOptions {
    /** The route key the adapter registers under. */
    readonly provider: string;
    /** The name selectors show for the route. */
    readonly displayName: string;
    /** The gateway origin, read per snapshot. */
    readonly origin: () => string;
    /** The current catalog; a new array identity means a new catalog. */
    readonly catalog: () => readonly GatewayModel[];
    /**
     * Read the catalog again because it is empty when models are listed, so a catalog read that missed a
     * fresh sign-in, or failed on a flaky network, recovers on the next list instead of the next timer.
     */
    readonly refreshCatalog?: () => Promise<void>;
    /** The credential for one request, or undefined when nobody is signed in and no key is configured. */
    readonly resolveCredential: () => Promise<GatewayCredential | undefined>;
    /** Hand a credential the gateway rejected back to its owner, which refreshes it or signs out. */
    readonly rejectCredential?: (credential: GatewayCredential) => Promise<void>;
    /** A stable device id for Anthropic session affinity. */
    readonly deviceId?: () => Promise<string | undefined>;
    readonly retryPolicy?: () => ResolvedRetryPolicy | undefined;
    readonly streamIdleTimeoutMs?: number;
    readonly cacheRetention?: 'none' | 'short' | 'long';
    readonly resolveAttachments?: () => AttachmentStore | undefined;
    readonly resolveImageAccess?: (attachments: AttachmentStore, ref: ImageAttachmentRef) => ImageAttachmentAccess | undefined;
    readonly onReplayDegrade?: (detail: {
        provider: string;
        model: string;
        reason: string;
    }) => void;
}
/**
 * The gateway as an LLM adapter. Each operation reads the current catalog, so a refresh reaches
 * the next request without a restart, while a request in flight finishes on the catalog it began with.
 */
export declare class GatewayAdapter extends LlmAdapter {
    private readonly config;
    private snapshot;
    constructor(config: GatewayAdapterOptions);
    private current;
    private assertOwned;
    private modelOf;
    providerInfo(provider: string): LlmProviderInfo;
    providerRetryPolicy(provider: string): ResolvedRetryPolicy | undefined;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string, _signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    private modelInfo;
    prepareCall(provider: string, model: string, _signal?: AbortSignal): Promise<PreparedAdapterCall>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    private streamWithSnapshot;
    /**
     * Fit pi-ai's payload to the gateway: Chat Completions gets the session's cache key (pi-ai sends it
     * only to api.openai.com), "off" is spelled out where the catalog offers `none`, and Responses
     * drops `temperature` while reasoning, which reasoning models refuse.
     */
    private shapePayload;
    /**
     * Hand a refused credential back to its owner (which refreshes it, or signs out when the gateway
     * ended the session) and return the credential that replaced it, if one did.
     * @param credential - the credential the gateway answered 401 to.
     * @returns a credential with a different token, or undefined when there is none to try.
     */
    private renew;
    /**
     * Turn a failed finish into the VibeDev failure the gateway status names: 402 is the balance
     * (with the top-up page), 401 a sign-in that has ended. Both carry this plugin's own codes and
     * messages, so the chat shows them instead of the DeepSeek account's prompts.
     */
    private accountFailure;
}
