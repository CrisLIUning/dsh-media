/**
 * pi-ai model descriptors and the multi-protocol provider for the gateway.
 *
 * A configured pi-ai route speaks one protocol, but one gateway serves Claude
 * over Messages, GPT and Grok over Responses, and DeepSeek and the rest over Chat
 * Completions. Every pi-ai `Model` carries its own `api`, so this provider
 * dispatches each request to the protocol module its model names, and the whole
 * catalog lives on one channel.
 *
 * @module dsh-vibedev/llm/models
 */
import type { Api, CreateModelsOptions, Model, ModelThinkingLevel, MutableModels, Provider, ThinkingLevelMap } from '@earendil-works/pi-ai';
import type { GatewayApi, GatewayModel, GatewayReasoningLevel } from './catalog.js';
/** Every pi-ai thinking level, in pi-ai's escalation order. */
export declare const THINKING_LEVELS: readonly ModelThinkingLevel[];
/**
 * pi-ai's level map for the catalog's levels. pi-ai offers `low`/`medium`/`high`
 * (and `minimal`) unless mapped to null, and `xhigh`/`max` only when mapped, so
 * every level the catalog leaves out is closed explicitly. `off` stays open only
 * when the catalog offers `none`; a model that always thinks never shows "off".
 * @param levels - the catalog's levels for one model.
 * @returns the map pi-ai reads to list and spell levels.
 */
export declare function thinkingLevelMap(levels: readonly GatewayReasoningLevel[]): ThinkingLevelMap;
/**
 * The endpoint root the protocol's SDK appends its path to: the Anthropic SDK adds
 * `/v1/messages` itself, the OpenAI SDK expects the `/v1` root.
 * @param origin - the gateway origin.
 * @param api - the model's protocol.
 * @returns the base URL for that protocol.
 */
export declare function baseUrlFor(origin: string, api: GatewayApi): string;
/**
 * Build pi-ai's descriptor for one catalog model on the given provider route.
 * @param model - the catalog model.
 * @param provider - the route the model is registered under.
 * @param origin - the gateway origin.
 * @returns the pi-ai model.
 */
export declare function toPiModel(model: GatewayModel, provider: string, origin: string): Model<Api>;
/**
 * The provider for one catalog snapshot: each request goes to the protocol module its model names.
 * @param input - route id, display name, and the snapshot's models.
 * @param input.id - the provider route key.
 * @param input.name - the display name.
 * @param input.models - pi-ai descriptors for the snapshot's models.
 * @returns the pi-ai provider.
 */
export declare function gatewayProvider(input: {
    id: string;
    name: string;
    models: readonly Model<Api>[];
}): Provider;
/**
 * Create an empty pi-ai collection. pi-ai's main entry builds one with no
 * providers; its `providers/all` entry would pull every provider's SDK (AWS,
 * Google, Mistral…) into this plugin's bundle for nothing.
 * @param options - credential storage and ambient authentication integrations.
 * @returns a mutable collection with no registered providers.
 */
export declare function createModels(options?: CreateModelsOptions): MutableModels;
/**
 * Selectable levels from pi-ai's view of one model, in escalation order.
 * @param model - descriptor carrying reasoning support and wire mappings.
 * @returns the supported levels.
 */
export declare function getSupportedThinkingLevels(model: Model<Api>): ModelThinkingLevel[];
