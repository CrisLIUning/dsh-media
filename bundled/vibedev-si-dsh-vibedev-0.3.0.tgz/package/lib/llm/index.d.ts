/**
 * The VibeDev gateway's chat models on their own route, `vibedev-gateway`, so
 * they sit in the model pickers next to whatever else the Harness offers — the
 * DeepSeek account's models included — and are paid from the VibeDev balance.
 *
 * The catalog comes from the gateway (`GET /v1/models`) with the credential
 * requests use, so nothing is listed before a sign-in: the catalog is per
 * account. It is read at start, on every sign-in, sign-out or account change,
 * and every `catalogRefreshMinutes`; a changed catalog republishes the route
 * so pickers update without a restart.
 *
 * Inside the VibeDev app the host account already serves these models on the
 * app's own account channel; when the credential comes from the host account
 * the route stays empty, so the pickers do not list every model twice.
 *
 * @module dsh-vibedev/llm
 */
import type { Context } from '@deepseek-ai/cordis';
import type { GatewayCredential } from './adapter.js';
import type { GatewayModel } from './catalog.js';
export { GatewayAdapter, INSUFFICIENT_BALANCE_CODE, SIGN_IN_REQUIRED_CODE } from './adapter.js';
export type { GatewayAdapterOptions, GatewayCredential } from './adapter.js';
export { parseCatalog } from './catalog.js';
export type { GatewayModel } from './catalog.js';
/** The route the gateway's chat models are listed under. */
export declare const VIBEDEV_ROUTE = "vibedev-gateway";
/** What the route needs from the rest of the plugin. */
export interface GatewayModelsOptions {
    /** Gateway origin, without a trailing slash. */
    readonly origin: string;
    /** The name pickers and the Models page show for the route. */
    readonly displayName: string;
    /** The credential for the next request, from the plugin's credential chain. */
    readonly resolveCredential: () => Promise<GatewayCredential | undefined>;
    /** Hand a credential the gateway refused back to its owner. */
    readonly rejectCredential: (credential: GatewayCredential) => Promise<void>;
    /** A stable id for this installation (Anthropic session affinity). */
    readonly deviceId: () => Promise<string>;
    /** Model ids listed first, in this order, when the catalog offers them. Read at every catalog read. */
    readonly preferredModels: () => readonly string[];
    /** Subscribe to sign-in changes; returns unsubscribe. */
    readonly onCredentialChange: (listener: () => void) => () => void;
    readonly catalogRefreshMinutes?: number;
    readonly catalogTimeoutMs?: number;
    readonly cacheRetention?: 'none' | 'short' | 'long';
}
/** The route's live state, for status lines and tests. */
export interface GatewayModels {
    /** Chat models listed now. */
    models(): readonly GatewayModel[];
    /** Why the route is empty, when it is. */
    hidden(): 'signed-out' | 'host-account' | undefined;
    /** Read the catalog now (after a sign-in, say); resolves when the read ends. */
    refresh(): Promise<void>;
}
/**
 * The catalog with the preferred models first, in their configured order, and the rest in catalog order.
 * @param models - the parsed catalog.
 * @param preferred - model ids to list first.
 * @returns the reordered catalog.
 */
export declare function preferredFirst(models: readonly GatewayModel[], preferred: readonly string[]): GatewayModel[];
/**
 * Register the route and keep its catalog current.
 * @param ctx - a context with the `llm` service.
 * @param options - origin, credentials and catalog policy.
 * @returns the route's live state.
 */
export declare function installGatewayModels(ctx: Context, options: GatewayModelsOptions): GatewayModels;
