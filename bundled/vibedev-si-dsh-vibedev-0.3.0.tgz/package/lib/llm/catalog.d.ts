/**
 * The VibeDev gateway's model catalog (`GET /v1/models`), narrowed to the chat
 * models this channel can serve and annotated with the wire protocol each one
 * is called over.
 *
 * The gateway answers with its VibeDev projection for signed, signature-exempt,
 * and app-token requests: every entry carries `protocol`, `capabilities` (context,
 * output, thinking, `reasoning_levels`, `default_reasoning`, modalities,
 * `allowed_endpoints`), and prices. Media generators, transcription models, and
 * the models the client drives itself (`internal_role`) are not chat models and
 * never reach the picker.
 *
 * @module dsh-vibedev/llm/catalog
 */
/** The wire protocols the gateway serves chat models over, named as pi-ai names them. */
export type GatewayApi = 'anthropic-messages' | 'openai-responses' | 'openai-completions';
/** A reasoning level as the gateway catalog spells it. */
export type GatewayReasoningLevel = 'none' | 'minimal' | 'low' | 'medium' | 'high' | 'xhigh' | 'max';
/** One chat model of the catalog with everything the adapter needs to describe and call it. */
export interface GatewayModel {
    readonly id: string;
    readonly name: string;
    /** The protocol requests for this model use. */
    readonly api: GatewayApi;
    readonly contextWindow: number;
    readonly maxTokens: number;
    readonly input: readonly ('text' | 'image')[];
    /**
     * Levels the user may pick, in escalation order; `undefined` when the catalog
     * states none (no level control), `[]` when the model thinks with no levels.
     */
    readonly reasoningLevels?: readonly GatewayReasoningLevel[];
    /** The level a new session starts on, when the catalog names one it offers. */
    readonly defaultReasoning?: GatewayReasoningLevel;
    /** Claude's effort-driven thinking, as opposed to a token budget. */
    readonly adaptiveThinking: boolean;
    /** Catalog prices per million tokens, in the catalog's currency (yuan). */
    readonly cost: {
        readonly input: number;
        readonly output: number;
        readonly cacheRead: number;
        readonly cacheWrite: number;
    };
}
/**
 * The protocol a model family is called over best, before the catalog's endpoint list has a say:
 * Claude speaks Messages natively; GPT, the o-series, Codex, and Grok keep their reasoning state
 * on Responses; everything else (DeepSeek, GLM, Kimi, Doubao, ...) passes through Chat Completions.
 * @param id - the catalog model id.
 * @returns the preferred protocol.
 */
export declare function preferredApi(id: string): GatewayApi;
/**
 * The protocol to call one catalog entry over: the family's preferred protocol when the
 * entry allows it, otherwise the first protocol it does allow. An entry listing no endpoint
 * this channel speaks (a native-only Gemini, say) has none.
 * @param id - the catalog model id.
 * @param allowed - the entry's `allowed_endpoints`, when it lists them.
 * @param protocol - the entry's `protocol`, used when it lists no endpoints.
 * @returns the protocol, or undefined when this channel cannot call the model.
 */
export declare function chooseApi(id: string, allowed: readonly string[] | undefined, protocol: string | undefined): GatewayApi | undefined;
/**
 * Parse one `/v1/models` body into the chat models this channel serves.
 * @param body - the decoded response: `{object, data: [...]}` or a bare array.
 * @returns the chat models, in catalog order; entries that are not chat models or cannot be called are left out.
 */
export declare function parseCatalog(body: unknown): GatewayModel[];
/**
 * The level a new session starts on: the catalog's default, else `high`, else the highest level
 * not above `high`, else the lowest level offered.
 * @param model - the catalog model.
 * @returns the starting level, or undefined when the model offers no levels.
 */
export declare function startingReasoning(model: GatewayModel): GatewayReasoningLevel | undefined;
