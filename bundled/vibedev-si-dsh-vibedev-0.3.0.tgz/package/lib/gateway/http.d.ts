/**
 * HTTP client for the VibeDev gateway. Every gateway call goes through here so
 * authentication, refresh after a 401, balance refusals, busy back-off and
 * idempotency are handled once.
 *
 * The credential is attached only to requests on the gateway origin: upload
 * URLs and third-party links never see it.
 * @module dsh-vibedev/gateway/http
 */
import { MediaError } from './errors.js';
import type { GatewayFailure } from './errors.js';
/** The credential one request carries. */
export interface GatewayCredential {
    readonly token: string;
    /**
     * Where it came from: the host's VibeDev account (`account`), the plugin's own
     * sign-in (`plugin`), or a development key from the environment (`key`). Only
     * account and plugin tokens can be refreshed after a 401.
     */
    readonly kind: 'account' | 'plugin' | 'key';
}
/** Construction options; `fetch` and `sleep` are test seams. */
export interface GatewayHttpOptions {
    /** Gateway origin, such as `https://api.vibedev.studio`. */
    readonly origin: string;
    /** The credential for the next request; undefined while nobody is signed in. */
    readonly resolveCredential: () => Promise<GatewayCredential | undefined>;
    /** Report a token the gateway rejected, so its owner refreshes it. */
    readonly rejectToken?: (credential: GatewayCredential) => Promise<void>;
    /** `User-Agent` for every request. */
    readonly userAgent: string;
    readonly fetch?: typeof globalThis.fetch;
    readonly sleep?: (ms: number, signal?: AbortSignal) => Promise<void>;
}
/** One request. */
export interface GatewayRequest {
    readonly method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
    /** JSON body; serialized with `content-type: application/json`. */
    readonly json?: unknown;
    /** Raw body (multipart form, bytes) when `json` is not used. */
    readonly body?: FormData | Uint8Array | string;
    readonly headers?: Readonly<Record<string, string>>;
    readonly signal?: AbortSignal;
    /** Deadline for each attempt. */
    readonly timeoutMs?: number;
    /** Sent as `Idempotency-Key`; makes a retried submission return the original task. */
    readonly idempotencyKey?: string;
    /** Send without the credential (pre-signed upload URLs, public content links). */
    readonly anonymous?: boolean;
    /** Retries after a busy answer (429, or 503 with a busy code or `Retry-After`). Defaults to 2. */
    readonly busyRetries?: number;
    /** Longest single wait for a busy answer; a longer `Retry-After` fails at once. Defaults to 15 s. */
    readonly maxBusyWaitMs?: number;
}
/** The message for a call made while nobody is signed in. */
export declare const SIGN_IN_MESSAGE: string;
/** Gateway HTTP client. */
export declare class GatewayHttp {
    private readonly options;
    readonly origin: string;
    /**
     * @param options - origin, credential plane, user agent and test seams.
     */
    constructor(options: GatewayHttpOptions);
    /** Absolute URL for a gateway path, or the URL itself when already absolute. */
    url(path: string): string;
    /** Whether a URL is on the gateway origin, and so may carry the credential. */
    isGatewayUrl(url: string): boolean;
    /**
     * Send one request and return the successful response.
     * @param path - gateway path, or an absolute URL.
     * @param request - method, body, headers and retry policy.
     * @returns the 2xx response, body unread.
     * @throws {@link MediaError} for every refusal, with the gateway's code.
     */
    send(path: string, request?: GatewayRequest): Promise<Response>;
    /**
     * Send one request and parse its JSON body.
     * @param path - gateway path, or an absolute URL.
     * @param request - method, body, headers and retry policy.
     * @returns the parsed body.
     */
    json<T = unknown>(path: string, request?: GatewayRequest): Promise<T>;
    private credential;
    private attempt;
}
/**
 * The error for an answer the client does not retry, worded for the model.
 * @param status - HTTP status.
 * @param failure - the parsed error body.
 * @param wait - Retry-After in milliseconds, when given.
 * @returns the error to throw.
 */
export declare function failureError(status: number, failure: GatewayFailure, wait?: number): MediaError;
