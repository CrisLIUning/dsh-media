/**
 * The gateway media library (`/v1/media-assets`): every reference a video
 * request carries is uploaded here first, so the gateway can check its type and
 * measure its length, and the provider fetches it from the gateway instead of
 * an arbitrary link.
 *
 * Flow: `POST /uploads` (deduplicated by content digest), `PUT upload_url` with
 * the returned upload headers when an upload is needed, `POST /{id}/complete`.
 * An asset the library already holds is read back through `/refresh`, which
 * also carries its measured duration.
 * @module dsh-vibedev/gateway/assets
 */
import type { GatewayHttp } from './http.js';
import type { LoadedMedia } from '../media/sources.js';
/** A media library asset a request can reference. */
export interface UploadedAsset {
    readonly assetId: string;
    /** The URL to put in a generation request. */
    readonly referenceUrl: string;
    readonly contentUrl?: string;
    readonly contentType: string;
    readonly expiresAt?: string;
    /** Measured length of an audio or video, in milliseconds. */
    readonly durationMs?: number;
    readonly sha256: string;
    readonly bytes: number;
}
/** Purposes the plugin uploads under. */
export type AssetPurpose = 'video_reference';
/**
 * Read an asset answer from `uploads`, `complete` or `refresh`.
 * @param body - the parsed answer.
 * @param fallbackType - the type the upload declared.
 * @returns the asset facts, or undefined when the answer names no usable URL.
 */
export declare function parseAsset(body: unknown, fallbackType: string): Omit<UploadedAsset, 'sha256' | 'bytes'> | undefined;
/** Uploads references and remembers them for the life of the plugin. */
export declare class MediaLibrary {
    private readonly http;
    private readonly now;
    private readonly cache;
    /**
     * @param http - the gateway client.
     * @param now - clock, for expiry checks.
     */
    constructor(http: GatewayHttp, now?: () => number);
    /** Forget every remembered asset, as after an account change: assets belong to the account that uploaded them. */
    clear(): void;
    /**
     * Upload one loaded input, or reuse the asset the library already holds.
     * @param media - the loaded input.
     * @param purpose - the asset purpose.
     * @param signal - cancels the upload.
     * @returns the asset.
     */
    upload(media: LoadedMedia, purpose: AssetPurpose, signal?: AbortSignal): Promise<UploadedAsset>;
    private expiring;
    private remember;
    private refresh;
    private read;
}
