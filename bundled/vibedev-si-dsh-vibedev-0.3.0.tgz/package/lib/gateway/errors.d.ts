/**
 * Failures the plugin reports to the model: a gateway refusal, or a request the
 * plugin refused before anything was sent or charged. Messages are written for
 * the model to act on and relay to the user.
 * @module dsh-vibedev/gateway/errors
 */
import { HarnessError } from '@deepseek-ai/dsh-llm';
/** Machine-readable detail carried next to the message. */
export interface MediaErrorDetails {
    /** HTTP status when the gateway answered. */
    readonly status?: number;
    /** Whether the same request may succeed later. */
    readonly retryable?: boolean;
    /** The request field the failure names, when the gateway says which. */
    readonly field?: string;
    /** Where the user tops up, on a balance refusal. */
    readonly rechargeUrl?: string;
    /** How long the gateway asked the client to wait. */
    readonly retryAfterMs?: number;
    /** The gateway was full and created nothing (a busy 429/503). */
    readonly busy?: boolean;
    /**
     * The gateway's structured submission state: `rejected` (the provider refused
     * the request; nothing exists under the key), `unknown` (the gateway cannot
     * tell whether the provider received it) or `accepted` (a task exists).
     * Absent on the older protocol, where the status is all there is.
     */
    readonly submissionState?: string;
    /**
     * What the gateway asks next: `none` (do not try again), `reconcile` (settle
     * the same key's outcome, do not create a task) or `retry`. `retryable` alone
     * only says recovery is still needed; it never means "create another task".
     */
    readonly retryAction?: string;
    /** On a task-limit refusal: tasks in progress and the account's limit. */
    readonly active?: number;
    readonly limit?: number;
    /** On an admission balance refusal: amounts in CNY, as the gateway's two-decimal strings. */
    readonly estimatedCny?: string;
    readonly availableCny?: string;
    readonly pendingCny?: string;
}
/**
 * One failure, with a stable `code` to route on and a message to show. It is a
 * harness error, so a tool failure keeps the code in the durable tool result
 * where a client can route on it (sign-in card, top-up link).
 */
export declare class MediaError extends HarnessError {
    readonly details: MediaErrorDetails;
    /**
     * @param message - what happened and what to do next.
     * @param code - stable failure class, such as `INSUFFICIENT_BALANCE` or `VIDEO_MODE_UNSUPPORTED`.
     * @param details - status, retry and field facts.
     * @param options - the underlying cause, when there is one.
     */
    constructor(message: string, code: string, details?: MediaErrorDetails, options?: ErrorOptions);
}
/** The parts of a gateway error body the plugin reads, whatever its shape. */
export interface GatewayFailure {
    readonly code?: string;
    readonly message?: string;
    readonly field?: string;
    readonly retryable?: boolean;
    readonly submissionState?: string;
    readonly retryAction?: string;
    readonly rechargeUrl?: string;
    readonly active?: number;
    readonly limit?: number;
    readonly estimatedCny?: string;
    readonly availableCny?: string;
    readonly pendingCny?: string;
}
/**
 * Read a gateway error body. The gateway answers in several shapes: OpenAI's
 * `{error:{code,message,type}}`, its own `{error:{code,message,retryable,field}}`,
 * the account API's `{code,message,reason}`, and a top-level `recharge_url` on
 * balance refusals. Media admission refusals add `active`/`limit` (task limit)
 * or `estimated_cny`/`available_cny`/`pending_cny` (balance).
 * @param body - the parsed JSON body, or undefined when it was not JSON.
 * @returns the fields found.
 */
export declare function parseGatewayFailure(body: unknown): GatewayFailure;
/**
 * Milliseconds a `Retry-After` header asks for: delta seconds or an HTTP date.
 * @param header - the header value, or null when absent.
 * @param now - current epoch milliseconds, for an HTTP date.
 * @returns the wait, or undefined when absent or unreadable.
 */
export declare function retryAfterMs(header: string | null, now?: number): number | undefined;
/** `(CODE: message)`, for appending the gateway's own words to a message. */
export declare function gatewayWords(failure: GatewayFailure): string;
