/** Production API origin. Storage URLs are returned by the server, not derived from this address. */
export declare const DEFAULT_GATEWAY_ORIGIN = "https://api.vibedev.studio";
/** Validate a bare HTTP(S) origin and canonicalize default ports, casing and trailing slash. */
export declare function normalizeGatewayOrigin(value: string): string;
/** Stable, filesystem-safe identity; ports and schemes remain separate boundaries. */
export declare function gatewayId(origin: string): string;
/** Every gateway uses its own namespace; never read the unmarked historical root. */
export declare function gatewayStateDirectory(root: string, origin: string): string;
/** Ignore the old shared key variable; development requires an explicitly named, gateway-specific variable. */
export declare function developmentKey(origin: string, name: string, env?: Readonly<Record<string, string | undefined>>): string | undefined;
