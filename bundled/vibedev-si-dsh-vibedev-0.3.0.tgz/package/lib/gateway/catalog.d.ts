/**
 * The media models of the VibeDev gateway catalog (`GET /v1/models`): image,
 * video, music/podcast and transcription models, with each model's declared
 * capabilities and price. Chat models and models the client drives itself
 * (`internal_role`) are left out.
 *
 * Video capabilities follow the gateway's `video` block: model-level limits plus
 * the versioned per-mode declarations (`modes_schema_version: 1`). A mode the
 * model does not list is unsupported; an unknown schema version makes the model
 * unusable rather than guessed at.
 * @module dsh-vibedev/gateway/catalog
 */
/** What a media model produces. */
export type MediaKind = 'image' | 'video' | 'audio' | 'transcription';
/** The video generation modes of catalog schema v1, under their wire names. */
export declare const VIDEO_MODES: readonly ["text_to_video", "first_frame", "first_last_frame", "omni_reference"];
export type VideoMode = typeof VIDEO_MODES[number];
/** The inputs a video request can carry, under the gateway's request field names. */
export declare const VIDEO_INPUTS: readonly ["firstFrame", "lastFrame", "referenceImages", "referenceVideos", "referenceAudios"];
export type VideoInput = typeof VIDEO_INPUTS[number];
/** How many of one input a mode accepts, and whether it must be a gateway-hosted asset. */
export interface VideoInputLimit {
    readonly min: number;
    readonly max: number;
    /** The input must be uploaded to the gateway media library first. */
    readonly hosted: boolean;
}
/** One mode's declaration. Lists that are absent inherit the model-level lists. */
export interface VideoModeConstraint {
    readonly inputs: Partial<Record<VideoInput, VideoInputLimit>>;
    /** At least one group must be fully present (each input at least once). Empty: no requirement. */
    readonly requiredAnyOf: readonly (readonly VideoInput[])[];
    readonly ratios?: readonly string[];
    readonly resolutions?: readonly string[];
    readonly durations?: readonly number[];
}
/** One allowed duration/ratio/resolution combination. */
export interface VideoCombination {
    readonly duration?: number;
    readonly ratio?: string;
    readonly resolution?: string;
}
/** A video model's declared capabilities. */
export interface VideoCapabilities {
    /**
     * Per-mode declarations. `undefined` for a legacy entry without modes, whose
     * modes are derived from the model-level fields by {@link effectiveVideoModes}.
     */
    readonly modes?: Partial<Record<VideoMode, VideoModeConstraint>>;
    /** A modes block was present but its schema version is not one this plugin reads. */
    readonly unreadableModesVersion?: number;
    readonly ratios?: readonly string[];
    readonly resolutions?: readonly string[];
    readonly durations?: readonly number[];
    readonly combinations?: readonly VideoCombination[];
    readonly nativeAudio?: boolean;
    readonly textToVideo?: boolean;
    readonly imageToVideo?: boolean;
    readonly firstFrame?: boolean;
    readonly lastFrame?: boolean;
    readonly maxReferenceImages?: number;
    readonly maxReferenceVideos?: number;
    readonly maxReferenceAudios?: number;
    readonly allowedImageMimes?: readonly string[];
    readonly allowedVideoMimes?: readonly string[];
    readonly allowedAudioMimes?: readonly string[];
    readonly maxReferenceImageBytes?: number;
    readonly maxReferenceVideoBytes?: number;
    readonly maxReferenceAudioBytes?: number;
    readonly maxAssetBytes?: number;
    readonly minReferenceVideoSeconds?: number;
    readonly maxReferenceVideoSeconds?: number;
    readonly maxTotalReferenceVideoSeconds?: number;
    /**
     * Declared limits on a reference AUDIO's own measured length. They are read
     * from the model, never assumed: a lane that declares nothing is not held to
     * another lane's range (some providers take 1–15 s, others take minutes).
     */
    readonly minReferenceAudioSeconds?: number;
    readonly maxReferenceAudioSeconds?: number;
    /** References must be relayed through the gateway media library. */
    readonly gatewayRelayRequired?: boolean;
}
/** One price tier: video tiers are resolutions (`720p`), image tiers size buckets (`1K`). */
export interface MediaPriceTier {
    readonly tier: string;
    readonly unit: 'generation' | 'second';
    readonly amount: number;
}
/** A model's selling price, account multiplier included. */
export interface MediaPricing {
    readonly currency: string;
    readonly tiers: readonly MediaPriceTier[];
    readonly default?: {
        readonly unit: 'generation' | 'second';
        readonly amount: number;
    };
}
/** One media model of the catalog. */
export interface MediaModel {
    readonly id: string;
    readonly name: string;
    readonly description?: string;
    readonly kind: MediaKind;
    /** For audio models: what they produce. */
    readonly audioKind?: 'music' | 'podcast';
    /** Endpoints the catalog lists for the model. */
    readonly endpoints: readonly string[];
    readonly inputModalities: readonly string[];
    readonly pricing?: MediaPricing;
    readonly video?: VideoCapabilities;
}
type Json = Record<string, unknown>;
/**
 * Parse a `video` capability block (or the legacy video fields inside `capabilities`).
 * @param raw - the block.
 * @returns the capabilities found.
 */
export declare function parseVideoCapabilities(raw: Json): VideoCapabilities;
/**
 * The modes a model can serve: its declared v1 modes, or for a legacy entry the
 * conservative set its model-level fields imply. An unreadable modes block serves none.
 * @param video - the model's capabilities.
 * @returns the usable modes and their constraints.
 */
export declare function effectiveVideoModes(video: VideoCapabilities): Partial<Record<VideoMode, VideoModeConstraint>>;
/**
 * Parse a `/v1/models` body into its media models.
 * @param body - `{data:[...]}` or a bare array.
 * @returns the media models, in catalog order.
 */
export declare function parseMediaCatalog(body: unknown): MediaModel[];
export {};
