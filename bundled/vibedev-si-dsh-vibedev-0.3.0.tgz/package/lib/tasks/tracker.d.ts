/**
 * Following video and audio tasks to the end: submit under the task's
 * idempotency key, poll the gateway, save the results into the workspace and
 * record the outcome. Polling belongs to the plugin, not to a tool call or a
 * background job, so a task keeps being followed after its job is stopped and
 * after the host restarts.
 *
 * Money rules, and the rule that one operation creates at most one task:
 *
 * - A submission is settled by the gateway's structured verdict
 *   (`submission_state` and `retry_action`) first, and only by the HTTP status
 *   when it sends none. `rejected`/`retry_action: none` is final: the reason is
 *   saved and nothing is sent again — not by the tool, not by the background
 *   loop, not after a restart. `retryable` on its own never authorizes creating
 *   another task.
 * - An unknown outcome keeps the record and settles it under the SAME key and
 *   the SAME body, which the gateway answers with the original task when there
 *   is one. A new key is minted only for a new request the user asks for.
 * - Once a gateway task id is known the task is only polled; a failed poll
 *   never submits anything.
 * - A refusal that left nothing under the key ends the record as failed with
 *   the gateway's own reason, so the person sees why.
 * @module dsh-vibedev/tasks/tracker
 */
import type { GatewayHttp } from '../gateway/http.js';
import type { RemoteTask } from './remote.js';
import type { TaskRecord, TaskStore } from './store.js';
/** Construction options; the clock and `sleep` are test seams. */
export interface TrackerOptions {
    readonly http: GatewayHttp;
    readonly store: TaskStore;
    readonly log?: (message: string) => void;
    readonly now?: () => number;
    /** Resolves after `ms`, or early when `signal` aborts; never rejects. */
    readonly sleep?: (ms: number, signal: AbortSignal) => Promise<void>;
    /** Give up on a task this long after it was created. Defaults to 3 hours. */
    readonly maxAgeMs?: number;
    /**
     * How long an unconfirmed submission is reconciled under its own key before
     * the task is given up. Defaults to 5 minutes: this settles what became of
     * that one submission, it never creates another task.
     */
    readonly resendWindowMs?: number;
    /** Download attempts for a finished task before its links are reported instead. Defaults to 5. */
    readonly downloadAttempts?: number;
    /** The largest output downloaded. Defaults to 2 GiB. */
    readonly maxDownloadBytes?: number;
    /** A claim not renewed for this long is taken over by another process. Defaults to 60 seconds. */
    readonly claimStaleMs?: number;
}
/**
 * How a failed submission may be taken further.
 *
 * - `rejected`: the request is refused for good (a parameter refusal, a
 *   provider-side rejection, a key conflict); nothing exists under the key and
 *   nothing may be created again for this operation.
 * - `reconcile`: the outcome is unknown — the same key and the same body are
 *   sent again only to settle what became of that one submission. This never
 *   mints a new key and never asks the provider for a new task.
 * - `wait`: nothing was created and the same request may be sent later (busy,
 *   rate limited, no balance); the key stays the same.
 */
export type SubmissionRecovery = 'rejected' | 'reconcile' | 'wait';
/**
 * What a failed submission means.
 *
 * The two STOP rules are read before anything that would keep the operation
 * alive, so no verdict can talk the plugin into sending a refused request
 * again: `retry_action: none` (the provider refused it) and
 * `VIDEO_SUBMISSION_AMBIGUOUS` (the gateway's key answers this forever) end the
 * operation even when the same answer also says the outcome is unknown.
 *
 * After those, the gateway's structured verdict decides, and only when it
 * sends none do the HTTP status and the older codes. `retryable` says recovery
 * is still needed; it never authorizes creating another task.
 * @param error - the failure.
 * @returns how it may be taken further.
 */
export declare function submissionRecovery(error: unknown): SubmissionRecovery;
/**
 * The live progress line of a running task.
 * @param task - the gateway's view.
 * @returns a short line such as `in progress 40%`.
 */
export declare function progressLine(task: RemoteTask): string;
/** Follows tasks; one poll loop per task. */
export declare class TaskTracker {
    private readonly options;
    private readonly following;
    private readonly submissions;
    private readonly listeners;
    private readonly claims;
    private readonly downloadFailures;
    private readonly controller;
    private readonly holder;
    private readonly now;
    private readonly sleep;
    /**
     * @param options - gateway client, store and test seams.
     */
    constructor(options: TrackerOptions);
    private get signal();
    private log;
    /**
     * Record and submit a new task. An outright refusal of the first attempt
     * throws and leaves no record. When the outcome stays open, the task stays
     * recorded and is resent in the background, and this throws `SUBMISSION_UNCONFIRMED`.
     * @param draft - the task, with status `submitting`.
     * @param signal - cancels waiting for the submission.
     * @returns the accepted task.
     */
    submit(draft: TaskRecord, signal?: AbortSignal): Promise<TaskRecord>;
    private runSubmission;
    /**
     * Follow a recorded task until it ends or the tracker is disposed. A task
     * still being submitted is followed once its submission settles.
     * @param id - the local task id.
     * @returns the task at the end (or at disposal, still running).
     */
    follow(id: string): Promise<TaskRecord>;
    private followQuietly;
    /**
     * Hear about every change to one task.
     * @param id - the local task id.
     * @param listener - called with the updated task.
     * @returns unsubscribe.
     */
    onUpdate(id: string, listener: (record: TaskRecord) => void): () => void;
    /** Follow every task that has not ended, as after a restart. */
    resume(): Promise<void>;
    /** Stop all polling and give up this process's claims; tasks stay recorded and are resumed next time. */
    dispose(): void;
    private notify;
    private update;
    private finish;
    /** Hold (or keep) this process's claim on a task, renewing it while held. */
    private holdClaim;
    private dropClaim;
    private releaseClaim;
    private loop;
    /**
     * Decide what a failed resend, poll or download means.
     * @returns how long to wait before the next try, or undefined once the task has been ended.
     */
    private afterFailure;
    /** Record what the gateway says about a task; save the outputs of a finished one. */
    private apply;
    /**
     * Save every output not saved yet, recording each one as it lands. A
     * shutdown mid-download throws, so the task stays open and is resumed.
     */
    private saveOutputs;
    /** Use a returned signed URL verbatim and without the app token; old gateways without a URL use `/content`. */
    private fetchOutput;
}
