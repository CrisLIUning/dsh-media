/**
 * The durable list of video and audio tasks, one file per task under
 * `<state dir>/tasks/`, so harness processes sharing a home never overwrite
 * each other's tasks. A task is recorded before it is submitted, under the id
 * that doubles as its `Idempotency-Key`: a submission cut short is resent under
 * the same key (the gateway returns the original task instead of creating a
 * second one), and a task still running when the host restarts is followed to
 * the end. A claim file names the process following a task, so two processes
 * never poll and download the same one.
 * @module dsh-vibedev/tasks/store
 */
/** What a task produces. */
export type TaskKind = 'video' | 'audio';
/**
 * `submitting`: recorded, not yet confirmed by the gateway. `pending`: the
 * gateway accepted it. `lost`: given up on (too old, or the gateway forgot it).
 */
export type TaskStatus = 'submitting' | 'pending' | 'completed' | 'failed' | 'lost';
/** One produced file. */
export interface TaskOutput {
    /** Position in the gateway's outputs. */
    readonly index?: number;
    /** Where it was saved; absent when the download failed. */
    readonly path?: string;
    /** The gateway's link to the file (valid for about 30 days). */
    readonly url?: string;
    readonly contentType?: string;
    readonly bytes?: number;
    readonly title?: string;
    readonly durationSeconds?: number;
}
/** One task. */
export interface TaskRecord {
    /** Local id; also the `Idempotency-Key` of the submission. */
    readonly id: string;
    readonly kind: TaskKind;
    readonly model: string;
    /** A short description for listings (a prompt excerpt). */
    readonly label: string;
    readonly createdAt: number;
    readonly updatedAt: number;
    /** The session that asked for it. */
    readonly owner?: string;
    /** Absolute directory the outputs are saved in. */
    readonly outputDir: string;
    /** File-name stem for the outputs. */
    readonly stem: string;
    /** The submission, kept so an unconfirmed one can be resent unchanged. */
    readonly endpoint: string;
    readonly body: Readonly<Record<string, unknown>>;
    readonly gatewayId?: string;
    readonly status: TaskStatus;
    readonly progress?: string;
    /** Outputs saved so far; a finished task lists every output. */
    readonly outputs?: readonly TaskOutput[];
    readonly error?: {
        readonly code: string;
        readonly message: string;
    };
    readonly estimatedCny?: string;
    readonly chargedCny?: string;
    readonly finishedAt?: number;
}
/**
 * Whether a task has ended.
 * @param record - the task.
 * @returns true for completed, failed and lost tasks.
 */
export declare function isFinished(record: Pick<TaskRecord, 'status'>): boolean;
/** Task records under `<state dir>/tasks/`. */
export declare class TaskStore {
    private readonly directory;
    private readonly now;
    private readonly chains;
    /**
     * @param directory - the plugin state directory.
     * @param now - clock.
     */
    constructor(directory: string, now?: () => number);
    private get dir();
    private file;
    /** Run one change to a task after the previous change to it in this process. */
    private serial;
    /** All tasks, newest first, as they are on disk now (other processes' tasks included). */
    list(): Promise<TaskRecord[]>;
    /**
     * One task.
     * @param id - its local id.
     * @returns the task, or undefined.
     */
    get(id: string): Promise<TaskRecord | undefined>;
    /**
     * Record a new task.
     * @param record - the task.
     * @returns the stored task.
     */
    add(record: TaskRecord): Promise<TaskRecord>;
    /**
     * Change a task.
     * @param id - its local id.
     * @param patch - the fields to replace.
     * @returns the updated task, or undefined when it is unknown.
     */
    update(id: string, patch: Partial<Omit<TaskRecord, 'id' | 'kind' | 'createdAt'>>): Promise<TaskRecord | undefined>;
    /**
     * Forget a task, such as a submission the gateway refused outright.
     * @param id - its local id.
     */
    remove(id: string): Promise<void>;
    /**
     * Claim the right to follow a task: free, already ours, or held by a process
     * that stopped renewing it for `staleMs`.
     * @param id - the task.
     * @param holder - this process's claim id.
     * @param staleMs - how old an unrenewed claim may be before it is taken over.
     * @returns whether this process now holds the claim.
     */
    claim(id: string, holder: string, staleMs: number): Promise<boolean>;
    /**
     * Keep a claim alive.
     * @param id - the task.
     * @param holder - this process's claim id.
     */
    renewClaim(id: string, holder: string): Promise<void>;
    /**
     * Give up a claim this process holds.
     * @param id - the task.
     * @param holder - this process's claim id.
     */
    release(id: string, holder: string): Promise<void>;
    private prune;
}
