/**
 * Reading the gateway's asynchronous task objects: `POST /v1/videos` and
 * `GET /v1/videos/{id}` (OpenAI video shape plus the gateway's `effective`
 * receipt and `asset`), and `POST /v1/audio/generations` and
 * `GET /v1/audio/generations/{id}` (`outputs[]`). Unknown statuses count as
 * still running; only an explicit terminal status ends a task.
 * @module dsh-vibedev/tasks/remote
 */
/** One produced file as the gateway describes it. */
export interface RemoteOutput {
    /** Position in `outputs[]`, for `/content?index=N`. */
    readonly index: number;
    readonly url?: string;
    readonly contentType?: string;
    readonly title?: string;
    readonly durationSeconds?: number;
}
/** A task's state. */
export interface RemoteTask {
    readonly id: string;
    readonly state: 'pending' | 'completed' | 'failed';
    /** The gateway's own status word. */
    readonly status: string;
    /** Percent done, when the gateway reports it. */
    readonly progress?: number;
    readonly error?: {
        readonly code: string;
        readonly message: string;
    };
    /** Estimated price at submission (CNY, two decimals). */
    readonly estimatedCny?: string;
    /** Settled charge (CNY); absent until the gateway settles, which is not the same as free. */
    readonly chargedCny?: string;
    readonly outputs: readonly RemoteOutput[];
}
/**
 * Read a video task.
 * @param body - the parsed answer.
 * @returns the task, or undefined when the answer names no task id.
 */
export declare function parseVideoTask(body: unknown): RemoteTask | undefined;
/**
 * Read a music or podcast task.
 * @param body - the parsed answer.
 * @returns the task, or undefined when the answer names no task id.
 */
export declare function parseAudioTask(body: unknown): RemoteTask | undefined;
