/**
 * dsh-vibedev (formerly dsh-media): the VibeDev account and the VibeDev
 * gateway for DeepSeek Harness — its chat models in the model pickers on their
 * own route (`vibedev-gateway`), next to the DeepSeek account's, and image,
 * video, music, podcast and speech-to-text tools for the agent.
 *
 * Everything is paid from the user's VibeDev balance: inside the VibeDev app
 * the app's signed-in account is used; elsewhere the plugin signs in to
 * VibeDev itself (the sidebar's "登录 VibeDev", Settings → VibeDev 账号, or the
 * `media_account` tool). The DeepSeek account stays the Harness's own.
 *
 * Kept from dsh-media so an upgrade carries over: the sign-in record
 * (`dsh-media/vibedev-session`), the data folder (`<harness home>/dsh-media`),
 * the `vibedevMedia` host service and the media tool names.
 *
 * ```yaml
 * - insert:
 *     - id: dsh-vibedev
 *       name: '@vibedev-si/dsh-vibedev'
 * ```
 * @module dsh-vibedev
 */
import type { Context, Volatile } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
export { MediaError } from './gateway/errors.js';
export { MediaHostService } from './service.js';
export type { HostTarget, MediaTaskView } from './service.js';
export type { ImageRequest } from './tools/image.js';
export type { VideoRequest } from './tools/video.js';
export { parseMediaCatalog } from './gateway/catalog.js';
export type { MediaModel, VideoCapabilities, VideoMode } from './gateway/catalog.js';
export { ACCOUNT_ROUTE_PREFIX, AccountService } from './account/index.js';
export type { AccountSource, AccountView } from './account/index.js';
export { GATEWAY_SEARCH_PROVIDER_ID as SEARCH_PROVIDER_ID } from './search/provider.js';
export { INSUFFICIENT_BALANCE_CODE, SIGN_IN_REQUIRED_CODE, VIBEDEV_ROUTE } from './llm/index.js';
/** The package version, sent in the `User-Agent` the gateway attributes plugin traffic by. */
export declare const version: string;
export declare const name = "dsh-vibedev";
export declare const inject: string[];
export interface Config {
    /** Name the model pickers and the Models page show for the VibeDev models. */
    displayName: string;
    /** VibeDev chat models listed first, in this order, when the catalog offers them. */
    preferredModels: string[];
    /** Open the system browser when a sign-in starts (off: the page opens the link itself). */
    openBrowserOnSignIn: boolean;
    /** Minutes between catalog reads while the app runs. */
    catalogRefreshMinutes: number;
    /** Ask the user before each paid request. */
    confirmSpending: Volatile<boolean>;
    /** Output folder, relative to the workspace (or absolute). */
    outputDir: Volatile<string>;
    /** Pinned models; empty lets the agent choose from the catalog. */
    imageModel: Volatile<string>;
    videoModel: Volatile<string>;
    musicModel: Volatile<string>;
    podcastModel: Volatile<string>;
    transcriptionModel: Volatile<string>;
    /** Gateway origin. */
    gatewayOrigin: string;
    /** Client name sent with the sign-in (`vibedev-plugin` in DeepSeek Harness; the VibeDev app sets its own). */
    client: string;
    /** The VibeDev account is the app's main account: its row leads the sidebar foot and Settings (the VibeDev app). */
    primary: boolean;
    /** Environment variable holding a development key, used only while nobody is signed in. */
    apiKeyEnv: string;
    /** Where tasks and the plugin's own sign-in are kept; empty for `<harness home>/dsh-media`. */
    stateDir: string;
}
export declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
    displayName: Schema<string, string, "defined">;
    preferredModels: Schema<string[], string[], "defined">;
    openBrowserOnSignIn: Schema<boolean, boolean, "defined">;
    catalogRefreshMinutes: Schema<number, number, "defined">;
    confirmSpending: Schema<boolean, boolean, "volatile-defined">;
    outputDir: Schema<string, string, "volatile-defined">;
    imageModel: Schema<string, string, "volatile-defined">;
    videoModel: Schema<string, string, "volatile-defined">;
    musicModel: Schema<string, string, "volatile-defined">;
    podcastModel: Schema<string, string, "volatile-defined">;
    transcriptionModel: Schema<string, string, "volatile-defined">;
    gatewayOrigin: Schema<string, string, "defined">;
    client: Schema<string, string, "defined">;
    primary: Schema<boolean, boolean, "defined">;
    apiKeyEnv: Schema<string, string, "defined">;
    stateDir: Schema<string, string, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    displayName: Schema<string, string, "defined">;
    preferredModels: Schema<string[], string[], "defined">;
    openBrowserOnSignIn: Schema<boolean, boolean, "defined">;
    catalogRefreshMinutes: Schema<number, number, "defined">;
    confirmSpending: Schema<boolean, boolean, "volatile-defined">;
    outputDir: Schema<string, string, "volatile-defined">;
    imageModel: Schema<string, string, "volatile-defined">;
    videoModel: Schema<string, string, "volatile-defined">;
    musicModel: Schema<string, string, "volatile-defined">;
    podcastModel: Schema<string, string, "volatile-defined">;
    transcriptionModel: Schema<string, string, "volatile-defined">;
    gatewayOrigin: Schema<string, string, "defined">;
    client: Schema<string, string, "defined">;
    primary: Schema<boolean, boolean, "defined">;
    apiKeyEnv: Schema<string, string, "defined">;
    stateDir: Schema<string, string, "defined">;
}>>, "plain">;
export declare function apply(ctx: Context, config: Config): void;
