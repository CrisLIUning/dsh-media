/**
 * What every media tool shares: the gateway client, the model catalog (cached
 * briefly), model choice, the workspace output folders, input loading
 * (workspace paths, links, data URLs and `chat:` attachments) and the optional
 * spending confirmation.
 * @module dsh-vibedev/runtime
 */
import type { AttachmentStore } from '@deepseek-ai/dsh-attachment';
import type { FileSystem } from '@deepseek-ai/dsh-fs';
import type { JobRegistry } from '@deepseek-ai/dsh-jobs';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import type { ApprovalService } from '@deepseek-ai/dsh-user-approval';
import type { MediaKind, MediaModel } from './gateway/catalog.js';
import type { GatewayHttp } from './gateway/http.js';
import type { MediaLibrary } from './gateway/assets.js';
import type { ChatMediaKind } from './media/chat.js';
import type { LoadedMedia } from './media/sources.js';
import type { TaskStore } from './tasks/store.js';
import type { TaskTracker } from './tasks/tracker.js';
/** The model a setting can pin per kind of output. */
export type ModelSlot = 'image' | 'video' | 'music' | 'podcast' | 'transcription';
/** Live settings (the plugin's volatile config). */
export interface MediaSettings {
    /** Output folder, relative to the workspace (or absolute). */
    readonly outputDir: () => string;
    readonly confirmSpending: () => boolean;
    /** A pinned model id, or `''` to let the agent choose. */
    readonly defaultModel: (slot: ModelSlot) => string;
}
/** Construction options. Optional services are read when used, since they can come and go. */
export interface RuntimeOptions {
    readonly http: GatewayHttp;
    readonly library: MediaLibrary;
    readonly tracker: TaskTracker;
    readonly store: TaskStore;
    readonly settings: MediaSettings;
    readonly stateDir: string;
    readonly fs?: () => FileSystem | undefined;
    readonly attachments?: () => AttachmentStore | undefined;
    readonly approval?: () => ApprovalService | undefined;
    readonly jobs?: () => JobRegistry | undefined;
    readonly now?: () => number;
    readonly log?: (message: string) => void;
}
/**
 * Who a media request runs for: an agent's tool call (a {@link ToolRunContext}
 * fits as it is), or a host caller such as the film workbench, which names the
 * workspace itself and shows the cost in its own interface first.
 */
export interface MediaCall {
    readonly signal: AbortSignal;
    readonly callId?: ToolRunContext['callId'];
    readonly agent?: ToolRunContext['agent'];
    /** The workspace, for callers without an agent session. */
    readonly cwd?: string;
    /** The caller already showed the cost and the user chose to go ahead. */
    readonly confirmed?: boolean;
}
/** Shared state and helpers of the media tools. */
export declare class MediaRuntime {
    readonly options: RuntimeOptions;
    private catalog;
    private fetching;
    private generation;
    readonly now: () => number;
    /**
     * @param options - gateway client, stores, settings and host services.
     */
    constructor(options: RuntimeOptions);
    get http(): GatewayHttp;
    get library(): MediaLibrary;
    get tracker(): TaskTracker;
    get store(): TaskStore;
    get settings(): MediaSettings;
    /**
     * The media models this account can use. Cached for two minutes; a failed
     * refresh falls back to the last list for up to an hour.
     * @param signal - cancels the request.
     * @returns the models, in catalog order.
     */
    models(signal?: AbortSignal): Promise<MediaModel[]>;
    /** Forget what belonged to the previous account (catalog and uploaded assets), as after a sign-in change. */
    accountChanged(): void;
    /** Forget the cached catalog. */
    invalidateCatalog(): void;
    /**
     * Choose the model for a request: the one asked for, else the pinned one,
     * else the first in catalog order that `accept` takes (or simply the first).
     * @param kind - the kind of output.
     * @param slot - the settings slot.
     * @param requested - the model the agent asked for, if any.
     * @param accept - whether a model can serve this request.
     * @param signal - cancels the catalog request.
     * @returns the model.
     */
    pickModel(kind: MediaKind, slot: ModelSlot, requested: string | undefined, accept?: (model: MediaModel) => boolean, signal?: AbortSignal): Promise<MediaModel>;
    /**
     * The workspace of the calling session.
     * @param call - the tool call or host call.
     * @returns its absolute working directory, when it has one.
     */
    workspace(call: MediaCall): string | undefined;
    /**
     * The absolute folder outputs of one kind are saved in: `<workspace>/<outputDir>/<sub>`.
     * Without a workspace, the plugin state directory is used.
     * @param call - the tool call or host call.
     * @param sub - `images`, `videos`, `audio` or `transcripts`.
     * @returns the folder (created on first write).
     */
    outputFolder(call: MediaCall, sub: string): string;
    /**
     * A file-name stem: the requested name, else a timestamp plus the start of the prompt.
     * @param filename - the agent's requested name, without extension.
     * @param prompt - the prompt.
     * @returns the stem.
     */
    stem(filename: string | undefined, prompt: string | undefined): string;
    /**
     * A path relative to the workspace when it is inside it, for messages.
     * @param call - the tool call or host call.
     * @param path - an absolute path.
     * @returns the display path.
     */
    display(call: MediaCall, path: string): string;
    private reader;
    /**
     * Load one input: a `chat:` attachment, a data URL, a link, or a path in the workspace.
     * @param call - the tool call or host call.
     * @param source - what the agent passed.
     * @param want - the kind the input needs.
     * @param maxBytes - the largest accepted file.
     * @returns the loaded media.
     */
    load(call: MediaCall, source: string, want: ChatMediaKind, maxBytes: number): Promise<LoadedMedia>;
    /**
     * Ask the user before spending, when the setting asks for it.
     * @param call - the tool call or host call.
     * @param toolName - the tool asking.
     * @param what - the request and its estimated price, in English and Chinese.
     * @throws {@link MediaError} when the user declines or nobody can answer.
     */
    confirmSpending(call: MediaCall, toolName: string, what: {
        en: string;
        zh: string;
    }): Promise<void>;
    /** The background-job registry, when the host has one. */
    jobs(): JobRegistry | undefined;
    /** Log through the host. */
    log(message: string): void;
}
