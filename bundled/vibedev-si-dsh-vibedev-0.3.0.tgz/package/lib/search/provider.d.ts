/**
 * `GatewaySearchProvider`: a `WebSearchProvider` backed by the VibeDev gateway's
 * `POST /v1/vibedev/web-search`. The gateway returns titles, snippets and
 * publication dates, not page bodies (`web_fetch` reads pages), plus instant
 * answers, which become the result's `content`.
 *
 * The gateway asks clients to send searches one at a time and to wait as
 * `Retry-After` says, so the provider queues searches (`web_search` runs one
 * call's queries in parallel) and waits out short rate-limit and busy answers
 * before giving up. A token the gateway rejects is reported back to where it
 * came from, which renews it, and the search is retried once.
 *
 * Ported from the VibeDev app's own search package
 * (`@vibedev/dsh-web-search-gateway`, provider.ts); here the credential is the
 * plugin's (host account, its own sign-in, or a development key).
 * @module dsh-vibedev/search/provider
 */
import type { WebSearchProvider, WebSearchRequest, WebSearchResult } from '@deepseek-ai/dsh-web';
import type { GatewayCredential } from '../gateway/http.js';
/** Stable id the provider registers under; a profile selects it as `web.searchProvider`. */
export declare const GATEWAY_SEARCH_PROVIDER_ID = "vibedev-gateway";
/** What the provider needs from its plugin, plus test seams. */
export interface GatewaySearchOptions {
    /** Absolute URL of the gateway's web-search endpoint. */
    readonly endpoint: string;
    /** The credential for the next request; undefined while nobody is signed in and no key is set. */
    readonly resolveCredential: () => Promise<GatewayCredential | undefined>;
    /** Report a credential the gateway rejected, so its source renews it. */
    readonly rejectCredential?: (credential: GatewayCredential) => Promise<void>;
    /** `User-Agent` sent with every request. */
    readonly userAgent: string;
    /** Deadline for one HTTP request. */
    readonly requestTimeoutMs: number;
    /** Retries after a rate-limited or busy answer. */
    readonly maxRetries: number;
    /** Longest `Retry-After` waited out; a longer one fails the search at once. */
    readonly maxRetryWaitMs: number;
    /** HTTP client; defaults to the global `fetch`. */
    readonly fetch?: typeof globalThis.fetch;
    /** Delay used for `Retry-After`; defaults to a timer that the search's signal cancels. */
    readonly sleep?: (ms: number, signal?: AbortSignal) => Promise<void>;
}
/**
 * Milliseconds a `Retry-After` header asks for: delta seconds or an HTTP date.
 * @param header - the header value, or null when absent.
 * @param now - the current epoch milliseconds, for an HTTP date.
 * @returns the wait, or undefined when the header is absent or unreadable.
 */
export declare function searchRetryAfterMs(header: string | null, now?: number): number | undefined;
/**
 * The request body: the query and, when bounded, the result count within the gateway's limits.
 * Any other field makes the gateway answer 400.
 * @param request - the seam request.
 * @returns the JSON body.
 */
export declare function requestBody(request: WebSearchRequest): string;
/**
 * Map a gateway search answer to the seam's result. Entries without a usable URL are dropped;
 * instant answers become `content`.
 * @param payload - the parsed response body.
 * @returns the normalized result.
 */
export declare function mapSearchResponse(payload: unknown): WebSearchResult;
/** Web search through the VibeDev gateway. */
export declare class GatewaySearchProvider implements WebSearchProvider {
    private readonly options;
    readonly id = "vibedev-gateway";
    private queue;
    /**
     * @param options - endpoint, credential plane, retry bounds, and test seams.
     */
    constructor(options: GatewaySearchOptions);
    /** Always usable: without a credential a search fails with a sign-in hint rather than an unselected provider. */
    available(): boolean;
    /**
     * Run one search after the ones already queued.
     * @param request - the query and optional result bound.
     * @param signal - cancels the search, queued or running.
     * @returns the normalized result.
     */
    search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult>;
    private searchNow;
    private credential;
    private post;
    private json;
}
