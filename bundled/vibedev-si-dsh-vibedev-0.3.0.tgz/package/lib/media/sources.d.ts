/**
 * Loading media inputs: a workspace path, an absolute path, an HTTP(S) link or a
 * `data:` URL. The type is read from the file's own header first, so a file
 * named `.png` that is really a JPEG is treated as a JPEG.
 * @module dsh-vibedev/media/sources
 */
/** One loaded input. */
export interface LoadedMedia {
    /** What the caller passed. */
    readonly source: string;
    /** A file name for uploads. */
    readonly name: string;
    readonly mime: string;
    readonly data: Uint8Array;
}
/** How paths are read; the tool layer backs it with the host's filesystem service. */
export interface SourceReader {
    readPath(path: string, maxBytes: number, signal?: AbortSignal): Promise<{
        data: Uint8Array;
        name: string;
    }>;
    readonly fetch?: typeof globalThis.fetch;
}
/**
 * The file extension for a MIME type.
 * @param mime - the type.
 * @param fallback - extension when the type is unknown.
 * @returns the extension, without a dot.
 */
export declare function extensionFor(mime: string, fallback?: string): string;
/**
 * The MIME type a file's leading bytes identify, falling back to its name.
 * @param data - the file bytes (the first 64 suffice).
 * @param name - the file name or path, for the extension fallback.
 * @returns the type, or `application/octet-stream` when unknown.
 */
export declare function sniffMime(data: Uint8Array, name?: string): string;
/**
 * Load one input.
 * @param source - path, URL or data URL.
 * @param reader - how paths are read, and the fetch to use for links.
 * @param maxBytes - the largest accepted size.
 * @param signal - cancels the load.
 * @returns the bytes, a name and the sniffed type.
 */
export declare function loadMedia(source: string, reader: SourceReader, maxBytes: number, signal?: AbortSignal): Promise<LoadedMedia>;
