/**
 * Media the user attached in the conversation, addressed as `chat:N` (the Nth
 * most recent attachment of the kind the input needs) or `chat:<kind>:N`
 * (`chat:image:1`, `chat:video:2`, `chat:audio:1`). The model sees attached
 * images but no path to them; this is how it can pass one on as a reference.
 * @module dsh-vibedev/media/chat
 */
import type { AttachmentStore, FileAttachmentRef, ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { Message } from '@deepseek-ai/dsh-llm';
import type { LoadedMedia } from './sources.js';
/** The media kinds a chat reference can name. */
export type ChatMediaKind = 'image' | 'video' | 'audio';
/** A parsed `chat:` reference. */
export interface ChatReference {
    /** The kind named in the reference, or undefined for `chat:N`. */
    readonly kind?: ChatMediaKind;
    /** 1 for the most recent. */
    readonly index: number;
}
/**
 * Parse a `chat:` reference.
 * @param source - what the model passed.
 * @returns the reference, or undefined when the source is not one.
 */
export declare function parseChatReference(source: string): ChatReference | undefined;
interface ChatItem {
    readonly kind: ChatMediaKind | 'other';
    readonly name: string;
    readonly image?: ImageAttachmentRef;
    readonly file?: FileAttachmentRef;
}
/**
 * The user's attachments, most recent first.
 * @param messages - the conversation, oldest first.
 * @returns images and files from user messages.
 */
export declare function chatAttachments(messages: readonly Message[]): ChatItem[];
/**
 * Load one `chat:` reference.
 * @param reference - the parsed reference.
 * @param want - the kind the input needs; `chat:N` counts only attachments of this kind.
 * @param messages - the conversation, oldest first.
 * @param store - the attachment store.
 * @param maxBytes - the largest accepted file.
 * @param signal - cancels the read.
 * @returns the loaded media.
 */
export declare function loadChatReference(reference: ChatReference, want: ChatMediaKind, messages: readonly Message[], store: AttachmentStore, maxBytes: number, signal?: AbortSignal): Promise<LoadedMedia>;
export {};
