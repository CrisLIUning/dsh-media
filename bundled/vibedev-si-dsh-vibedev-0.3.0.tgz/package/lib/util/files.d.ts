/**
 * Files the plugin writes: its state directory, output names in the
 * workspace, and atomic writes of generated media. Content is written to a
 * temporary file first and moved into place only when complete, so a crash
 * never leaves a half-written or empty file under a final name.
 * @module dsh-vibedev/util/files
 */
/**
 * The harness home: `$DSH_HOME` when set (VibeDev sets it to its own home),
 * else `~/.dsh`, the same rule the harness itself applies.
 * @param env - the environment.
 * @returns the absolute home directory.
 */
export declare function harnessHome(env?: Readonly<Record<string, string | undefined>>): string;
/**
 * The plugin's own state directory: the configured one, else `<harness home>/dsh-media`
 * (the plugin's former name, kept so an upgrade keeps its tasks and device id).
 * @param configured - the `stateDir` setting; empty for the default.
 * @param env - the environment.
 * @returns the absolute directory.
 */
export declare function stateDirectory(configured: string, env?: Readonly<Record<string, string | undefined>>): string;
/**
 * A file-name stem from free text: characters no file system accepts are
 * dropped, whitespace becomes `-`, and the result is cut to `max` characters.
 * @param text - a prompt or a requested name.
 * @param max - the longest stem, in characters.
 * @returns the stem, possibly empty.
 */
export declare function safeStem(text: string, max?: number): string;
/**
 * A sortable local timestamp for file names (`20261003-165012`).
 * @param date - the moment.
 * @returns the timestamp.
 */
export declare function fileTimestamp(date: Date): string;
/**
 * Rename, retrying the transient refusals Windows gives while a virus scanner
 * or the indexer holds the file.
 * @param from - the current path.
 * @param to - the new path; an existing file is replaced.
 */
export declare function renameWithRetry(from: string, to: string): Promise<void>;
/**
 * Move a complete temporary file to the first free name `dir/stem.ext`
 * (then `stem-2.ext`, ...), never replacing an existing file.
 * @param temporary - the complete file.
 * @param dir - the destination directory, created when missing.
 * @param stem - the file-name stem.
 * @param extension - the extension, without a dot.
 * @returns the final path.
 */
export declare function placeFile(temporary: string, dir: string, stem: string, extension: string): Promise<string>;
/**
 * Save bytes under the first free name `dir/stem.ext`.
 * @param dir - the destination directory.
 * @param stem - the file-name stem.
 * @param extension - the extension, without a dot.
 * @param data - the content.
 * @returns the final path.
 */
export declare function saveNewFile(dir: string, stem: string, extension: string, data: Uint8Array): Promise<string>;
/**
 * Write bytes atomically, replacing the file.
 * @param path - the final path.
 * @param data - the content.
 * @param options - `mode` for a file only its owner may read.
 */
export declare function writeFileAtomic(path: string, data: Uint8Array, options?: {
    mode?: number;
}): Promise<void>;
/**
 * Stream a response body into a temporary file, replacing what was there.
 * @param response - a successful response whose body is unread.
 * @param temporary - where to write; the caller moves it into place when this resolves.
 * @param maxBytes - the largest accepted body.
 * @param signal - cancels the download.
 * @returns the number of bytes written.
 */
export declare function downloadTo(response: Response, temporary: string, maxBytes: number, signal?: AbortSignal): Promise<number>;
