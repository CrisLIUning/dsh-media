/**
 * `media_account`: which VibeDev account the VibeDev models and media requests
 * use, and the plugin's own sign-in for hosts without a VibeDev account
 * (official DeepSeek Harness). People can also sign in from the sidebar or
 * Settings → VibeDev 账号; this is the agent's way to the same sign-in.
 * @module dsh-vibedev/tools/account
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { CredentialChain } from '../auth/credentials.js';
import type { PluginLogin } from '../auth/login.js';
import type { MediaRuntime } from '../runtime.js';
/**
 * Build the tool.
 * @param runtime - the media runtime.
 * @param chain - the credential chain.
 * @param login - the plugin's own sign-in.
 * @returns the tool definition.
 */
export declare function mediaAccountTool(runtime: MediaRuntime, chain: CredentialChain, login: PluginLogin): ToolDefinition;
