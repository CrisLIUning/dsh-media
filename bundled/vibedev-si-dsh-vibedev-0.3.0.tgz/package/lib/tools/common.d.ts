/**
 * Pieces the media tools share: how inputs are described to the model, the
 * background job that reports a video or audio task, and the wording of task
 * outcomes.
 * @module dsh-vibedev/tools/common
 */
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import type { MediaRuntime } from '../runtime.js';
import type { TaskRecord } from '../tasks/store.js';
declare module '@deepseek-ai/dsh-jobs' {
    interface JobKindMap {
        'media-video': 'media-video';
        'media-audio': 'media-audio';
    }
}
/** How a media input may be given, for parameter descriptions. */
export declare const SOURCE_HELP = "a workspace file path, an http(s) link, or chat:1 for the most recent matching file the user attached in this conversation (chat:2 the one before)";
/**
 * A prompt excerpt for labels.
 * @param prompt - the prompt.
 * @param max - the longest excerpt.
 * @returns the excerpt.
 */
export declare function excerpt(prompt: string | undefined, max?: number): string;
/**
 * The charge line of a finished task.
 * @param record - the task.
 * @returns `Charged ¥4.95.`, an estimate, or the empty string.
 */
export declare function moneyLine(record: TaskRecord): string;
/**
 * The model-facing account of a task's current state.
 * @param runtime - for display paths.
 * @param exec - the tool call, for workspace-relative paths; optional after a restart.
 * @param record - the task.
 * @returns the text.
 */
export declare function describeTask(runtime: MediaRuntime, exec: ToolRunContext | undefined, record: TaskRecord): string;
/**
 * Report a submitted task through a background job owned by the calling
 * session, so the agent hears when it ends. Stopping the job stops the report,
 * not the task: the gateway has no cancel, so the task still finishes, is saved
 * and is charged.
 * @param runtime - the media runtime.
 * @param exec - the submitting tool call.
 * @param record - the accepted task.
 * @returns the job id, or undefined when the host has no job registry or refused the job.
 */
export declare function startTaskJob(runtime: MediaRuntime, exec: ToolRunContext, record: TaskRecord): string | undefined;
/** A submitted task and how it is reported. */
export interface Submitted {
    readonly record: TaskRecord;
    /** The background job reporting it, when the host has a job registry. */
    readonly jobId?: string;
    /** The gateway did not confirm the submission; it is being resent under the same key. */
    readonly unconfirmed: boolean;
}
/**
 * Submit a task and start its report. An unconfirmed submission is not an
 * error here: the agent must not resubmit it, so it is reported like any
 * other task while the tracker settles that one submission under the same key.
 * @param runtime - the media runtime.
 * @param exec - the tool call.
 * @param draft - the task to submit.
 * @returns the task and its job.
 */
export declare function submitTask(runtime: MediaRuntime, exec: ToolRunContext, draft: TaskRecord): Promise<Submitted>;
/** The sentence about an unconfirmed submission. */
export declare const UNCONFIRMED_NOTE: string;
/**
 * Wait for a task in the tool call itself, for hosts without background jobs.
 * @param runtime - the media runtime.
 * @param exec - the tool call; aborting stops waiting, not the task.
 * @param record - the accepted task.
 * @returns the task when it ended, or as it stands when the wait was cut short.
 */
export declare function waitForTask(runtime: MediaRuntime, exec: ToolRunContext, record: TaskRecord): Promise<TaskRecord>;
