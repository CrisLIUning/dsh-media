/**
 * `video_generate`: plan a video request against what the chosen model
 * declares, upload every reference to the gateway media library, check the
 * measured reference lengths, submit once under an idempotency key and report
 * the result through a background job.
 * @module dsh-vibedev/tools/video
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { MediaModel, VideoInput } from '../gateway/catalog.js';
import type { MediaCall, MediaRuntime } from '../runtime.js';
import type { TaskRecord } from '../tasks/store.js';
import type { VideoPlan, VideoRequestOptions } from '../video/plan.js';
/** One video request, as the tool and host callers make it. */
export interface VideoRequest extends VideoRequestOptions {
    readonly model?: string;
}
/** A video request checked, uploaded and priced, ready to submit. */
export interface PreparedVideo {
    readonly model: MediaModel;
    readonly plan: VideoPlan;
    /** The task to submit (status `submitting`). */
    readonly draft: TaskRecord;
    /** One entry per uploaded input, in request order. */
    readonly inputs: readonly VideoInput[];
    /** `5 s, 16:9, 720p`, for messages. */
    readonly shape: string;
}
/**
 * Everything before a video submission: choose a model that can serve the
 * request, load and check every input, upload them all to the gateway media
 * library, check the measured reference lengths, price it, confirm the
 * spending, and build the task.
 * @param runtime - the media runtime.
 * @param call - the tool call or host call.
 * @param request - what to generate.
 * @param save - where the finished video goes: the folder and the file-name stem.
 * @returns the prepared task.
 */
export declare function prepareVideoTask(runtime: MediaRuntime, call: MediaCall, request: VideoRequest, save: {
    readonly folder: string;
    readonly stem: string;
}): Promise<PreparedVideo>;
/**
 * Build the tool.
 * @param runtime - the media runtime.
 * @returns the tool definition.
 */
export declare function videoGenerateTool(runtime: MediaRuntime): ToolDefinition;
