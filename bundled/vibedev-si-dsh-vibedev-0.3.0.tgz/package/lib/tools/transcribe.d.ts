/**
 * `audio_transcribe`: speech to text with a VibeDev transcription model.
 * Short files answer directly; long ones become a task that is polled here.
 * @module dsh-vibedev/tools/transcribe
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { MediaRuntime } from '../runtime.js';
/**
 * The length of a PCM WAV file from its header.
 * @param data - the file bytes.
 * @returns seconds, or undefined when the header cannot be read.
 */
export declare function wavSeconds(data: Uint8Array): number | undefined;
/**
 * Build the tool.
 * @param runtime - the media runtime.
 * @returns the tool definition.
 */
export declare function audioTranscribeTool(runtime: MediaRuntime): ToolDefinition;
