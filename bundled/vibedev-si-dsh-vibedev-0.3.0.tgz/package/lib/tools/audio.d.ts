/**
 * `audio_generate`: a song or a podcast episode, as a background task whose
 * results are saved in the workspace.
 * @module dsh-vibedev/tools/audio
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { MediaRuntime } from '../runtime.js';
/**
 * Build the tool.
 * @param runtime - the media runtime.
 * @returns the tool definition.
 */
export declare function audioGenerateTool(runtime: MediaRuntime): ToolDefinition;
