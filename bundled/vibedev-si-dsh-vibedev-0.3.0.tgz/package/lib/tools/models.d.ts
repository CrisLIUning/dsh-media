/**
 * `media_models`: the media models this VibeDev account can use, with prices
 * and, for video, what each generation mode accepts.
 * @module dsh-vibedev/tools/models
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { MediaRuntime } from '../runtime.js';
/**
 * Build the tool.
 * @param runtime - the media runtime.
 * @returns the tool definition.
 */
export declare function mediaModelsTool(runtime: MediaRuntime): ToolDefinition;
