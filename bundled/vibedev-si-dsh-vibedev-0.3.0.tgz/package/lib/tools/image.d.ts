/**
 * `image_generate`: generate images, or edit/derive from reference images,
 * save them in the workspace and show them to the model.
 * @module dsh-vibedev/tools/image
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { MediaCall, MediaRuntime } from '../runtime.js';
/** One image request, as the tool and host callers make it. */
export interface ImageRequest {
    readonly prompt: string;
    readonly model?: string;
    /** `WIDTHxHEIGHT` or `auto`. */
    readonly size?: string;
    readonly quality?: string;
    /** 1-4. */
    readonly n?: number;
    /** Images to edit or draw from: paths, links, data URLs or `chat:` references. */
    readonly references?: readonly string[];
}
/** One saved image. */
export interface GeneratedImage {
    readonly absolutePath: string;
    readonly mediaType: string;
    readonly bytes: number;
    readonly data: Uint8Array;
}
/**
 * Generate images and save them: model choice, reference checks, the spending
 * confirmation, the gateway call and the files.
 * @param runtime - the media runtime.
 * @param call - the tool call or host call.
 * @param request - what to generate.
 * @param save - where: the folder and the file-name stem (`-2`, `-3`... for more than one).
 * @returns the model, the saved images, the estimate and a revised prompt.
 */
export declare function generateImages(runtime: MediaRuntime, call: MediaCall, request: ImageRequest, save: {
    readonly folder: string;
    readonly stem: string;
}): Promise<{
    model: string;
    images: GeneratedImage[];
    estimatedCny?: string;
    revisedPrompt?: string;
}>;
/**
 * Build the tool.
 * @param runtime - the media runtime.
 * @returns the tool definition.
 */
export declare function imageGenerateTool(runtime: MediaRuntime): ToolDefinition;
