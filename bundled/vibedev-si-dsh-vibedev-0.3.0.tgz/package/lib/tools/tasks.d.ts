/**
 * `media_tasks`: the video and audio tasks dsh-vibedev is following or has
 * finished, newest first.
 * @module dsh-vibedev/tools/tasks
 */
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { MediaRuntime } from '../runtime.js';
/**
 * Build the tool.
 * @param runtime - the media runtime.
 * @returns the tool definition.
 */
export declare function mediaTasksTool(runtime: MediaRuntime): ToolDefinition;
