/**
 * Price estimates from the catalog's `media_pricing` (selling prices with the
 * account multiplier applied). The gateway estimates the same way at admission:
 * per-second video prices times billed seconds, where billed seconds are the
 * output length plus the summed reference video length, rounded up once.
 * Estimates are for the user's information; the gateway's receipt is the charge.
 * @module dsh-vibedev/pricing
 */
import type { MediaModel } from './gateway/catalog.js';
/** One estimate. */
export interface Estimate {
    readonly amountCny: number;
    /** How it was reached, such as `¥0.99/s × 5 s`. */
    readonly basis: string;
}
/**
 * Format an amount in yuan.
 * @param amount - the amount.
 * @returns `¥4.95`.
 */
export declare function yuan(amount: number): string;
/**
 * A one-line price for listings: `¥0.10 per image`, `¥0.99/s (720p)`.
 * @param model - the model.
 * @returns the price, or undefined when the catalog gives none.
 */
export declare function describePrice(model: MediaModel): string | undefined;
/**
 * Estimate an image request.
 * @param model - the image model.
 * @param count - images requested.
 * @returns the estimate, or undefined without a price.
 */
export declare function estimateImages(model: MediaModel, count: number): Estimate | undefined;
/**
 * Estimate a video request.
 * @param model - the video model.
 * @param duration - the requested length in seconds, when given.
 * @param resolution - the requested resolution, when given.
 * @param referenceMs - the summed length of the reference videos.
 * @returns the estimate, or undefined without a price.
 */
export declare function estimateVideo(model: MediaModel, duration: number | undefined, resolution: string | undefined, referenceMs?: number): Estimate | undefined;
/**
 * Estimate a music or podcast request.
 * @param model - the audio model.
 * @returns the estimate, or undefined without a price.
 */
export declare function estimateAudio(model: MediaModel): Estimate | undefined;
